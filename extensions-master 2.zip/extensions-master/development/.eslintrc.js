module.exports = {
  env: {
    commonjs: true,
    node: true,
  }
};
