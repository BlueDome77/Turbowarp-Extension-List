DO NOT use these test extensions. They WILL be deleted and modified in ways that break your project, and they don't have any blocks you would actually want to use.
